README for MRIConvert
20130129

Installation
------------
First, untar the tarball into a convenient location. If you
are reading this file, you have already done so.

Change directory to the resulting MRIConvert directory and
run the following command to install the main program files:

sh install.sh

