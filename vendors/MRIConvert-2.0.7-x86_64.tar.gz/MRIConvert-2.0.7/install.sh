#!/bin/sh

echo "Installing MRIConvert"
cp -r usr /

echo "Fixing permissions"
chmod 755 /usr/bin/MRIConvert \
          /usr/bin/mcverter \
          /usr/share/doc/mriconvert
chmod 644 /usr/share/doc/mriconvert/* \
          /usr/share/man/man1/MRIConvert.1.gz \
          /usr/share/man/man1/mcverter.1.gz

echo "Done!"
